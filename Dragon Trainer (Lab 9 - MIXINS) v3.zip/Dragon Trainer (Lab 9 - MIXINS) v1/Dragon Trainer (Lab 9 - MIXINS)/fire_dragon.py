# fire_dragon.py
import random
from dragon import Dragon
from fire import Fire

class FireDragon(Dragon, Fire):
    def __init__(self):
        super().__init__()
        self._special_attack = 3

    def special_attack(self, opponent):
        if self._special_attack > 0:
            choice = random.choice([self.fireball, self.fireblast])  # Choose a method
            self.decrement_special()  # Decrement special attacks
            return choice(self, opponent)  # Call the chosen method
        else:
            return "No special attacks remaining!"

    def decrement_special(self):
        self._special_attack = max(0, self._special_attack - 1)
