import dragon, fire, flying, random

class FlyingFireDragon():
    def fireblast(self, opponent):
        # if the dragon has any special attacks left, then it blasts the hero with fire 
        if self.special_attacks > 0:
            # take a random amount of damage in the range 5-9 
            damage = random.randint(5,9)
            # the number of special attacks is decremented. 
            self.special_attacks -= 1
            # Return a string with a description of the attack and the damage dealt to the hero. 
            return f"The dragon blasts fire on {opponent.name}, dealing {damage} damage!"
        # Otherwise, no damage is done and a string describing the failure is returned
        else: 
            return f"The dragon tries to blast fire, but it is too tired to perform any special attacks."

    def fireball(self,opponent):
        #if the dragon has any special attacks left
        if self.special_attack > 0:
            # it spits a fireball at the hero and they take a random amount of damage in the range 4-8 
            damage = random.randint(4,8)
            # the number of special attacks is decremented. 
            self.speical_attack -= 1
            # Return a string with a description of the attack and the damage dealt to the hero. 
            return f"The dragon blasts a fire ball on {opponent.name}, dealing {damage} damage!"
        # Otherwise, no damage is done and a string describing the failure is returned
        else: 
            return f"The dragon tries to blast a fire ball, but it is too tired to perform any special attacks."