import random

class Flying():
    @staticmethod
    def swoop(self, opponent):
        # if the dragon has any special attacks left
        if self._special_attacks > 0:
            # then it does a swoop attack at the hero and they take a random amount of damage in the range 4-8
            damage = random.randint(4,8)
            opponent.take_damage(damage)
            # the number of special attacks is decremented. 
            self._special_attacks -= 1
            # Return a string with a description of the attack and the damage dealt to the hero. 
            return f"The dragon swoops down on {opponent.name}, dealing {damage} damage!"
        else:
            # Otherwise, no damage is done and a string describing the failure is returned.
            return f"The dragon tries to swoop, but it is too tired to perform any special attacks."

    def windblast(self, opponent):
        # if the dragon has any special attacks left, then it blasts wind at the hero
        if self._special_attacks > 0:
            # they take a random amount of damage in the range 3-7 
            damage = random.randint(3,7)
            opponent.take_damage(damage)
            # the number of special attacks is decremented
            self._special_attacks -= 1
            # Return a string with a description of the attack and the damage dealt to the hero. 
            return f"The dragon blasts {opponent.name} with wind, dealing {damage} damage!"
        else:
            # Otherwise, no damage is done and a string describing the failure is returned
            return f"The dragon tries to blast wind, but it is too tired to perform special attacks."