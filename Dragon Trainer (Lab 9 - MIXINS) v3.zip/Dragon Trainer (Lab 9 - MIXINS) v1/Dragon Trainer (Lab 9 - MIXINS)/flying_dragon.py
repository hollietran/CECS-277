from dragon import Dragon
from flying import Flying
import random

class FlyingDragon(Dragon, Flying):
    def __init__(self):
        #call super to set a default name, hp, and number of special attacks
        super().__init__()
        Dragon.__init__(self)  
        Flying.__init__(self)
        self._special_attack = 3

    def special_attack(self, oppoonent):
        #Randomly choose one of the two flying attacks methods from Flying mixin
        choice = random.randint(1,2)
        if choice == 1:
            Flying.swoop("Dragon", "Hero")
        else:
            Flying.windblast("Dragon", "Hero")
        